from urllib.request import Request, urlopen
from bs4 import BeautifulSoup

site = "https://www.fortytwo.sg/versalift-transforming-coffee-dining-table-oak.html"

hdr = {'User-Agent': 'Mozilla/5.0'}
req = Request(site,headers=hdr)
page = urlopen(req)
soup = BeautifulSoup(page, 'html.parser')

#new-price
new_price_element = soup.find(class_="new-price")

print("Current Price: " + new_price_element.text)


#old-price
old_price_element = soup.find(class_="old-price")

print("\nOld Price: " + old_price_element.text)


from datetime import datetime

# Get current date and time
now = datetime.now()

# Format as "20-Aug-2025, 1500hr"
formatted = now.strftime("%d-%b-%Y, %H%Mhr")

#print(formatted)


price_data = open("table.txt", "a")
price_data.write(formatted + ":" + new_price_element.text + "\n")
price_data.close()