import os
import re
import pandas as pd
from pptx import Presentation

# -----------------------------
# Configuration
# -----------------------------
TEMPLATE_FILE = "certificate.pptx"
EXCEL_FILE = "participants.xlsx"
OUTPUT_FOLDER = "pptx"

PLACEHOLDER = "<<name>>"
COLUMN_NAME = "name"

# -----------------------------
# Create output folder
# -----------------------------
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# -----------------------------
# Read participant list
# -----------------------------
df = pd.read_excel(EXCEL_FILE)

if COLUMN_NAME not in df.columns:
    raise ValueError(f"Column '{COLUMN_NAME}' not found in {EXCEL_FILE}")

# -----------------------------
# Helper function
# -----------------------------
def replace_placeholder(shape, placeholder, replacement):
    """Replace placeholder in all text runs within a shape."""
    if not shape.has_text_frame:
        return

    for paragraph in shape.text_frame.paragraphs:
        full_text = "".join(run.text for run in paragraph.runs)

        if placeholder not in full_text:
            continue

        new_text = full_text.replace(placeholder, replacement)

        # Keep formatting of the first run
        if paragraph.runs:
            paragraph.runs[0].text = new_text
            for run in paragraph.runs[1:]:
                run.text = ""

def process_shapes(shapes, placeholder, replacement):
    """Recursively process shapes and grouped shapes."""
    for shape in shapes:

        # Normal text boxes/placeholders
        if hasattr(shape, "text_frame"):
            replace_placeholder(shape, placeholder, replacement)

        # Tables
        if shape.has_table:
            for row in shape.table.rows:
                for cell in row.cells:
                    replace_placeholder(cell, placeholder, replacement)

        # Grouped shapes
        if shape.shape_type == 6:  # MSO_SHAPE_TYPE.GROUP
            process_shapes(shape.shapes, placeholder, replacement)

# -----------------------------
# Generate certificates
# -----------------------------
for _, row in df.iterrows():
    name = str(row[COLUMN_NAME]).strip()

    if not name:
        continue

    prs = Presentation(TEMPLATE_FILE)

    for slide in prs.slides:
        process_shapes(slide.shapes, PLACEHOLDER, name)

    # Remove characters not allowed in filenames
    safe_name = re.sub(r'[\\/*?:"<>|]', "", name)

    output_file = os.path.join(OUTPUT_FOLDER, f"{safe_name}.pptx")
    prs.save(output_file)

    print(f"Created: {output_file}")

print("Done!")