import os
import io
import pandas as pd
import requests
from PIL import Image
from pptx import Presentation
from pptx.util import Inches, Pt

# ==========================================
# STEP 1: Generate sample Excel file dynamically
# ==========================================
excel_file = "property_listings.xlsx"



# ==========================================
# STEP 2: Process data and build PowerPoint
# ==========================================
# Read the Excel file back into pandas
df = pd.read_excel(excel_file)

# Initialize a blank PowerPoint presentation
prs = Presentation()
blank_slide_layout = prs.slide_layouts[6]  # Blank layout

os.makedirs("temp_images", exist_ok=True)

for _, row in df.iterrows():
    # 1. Fetch image from URL using requests
    response = requests.get(row["image_url"], timeout=10)
    
    if response.status_code == 200:
        # 2. Process image using Pillow (verify and save locally)
        img = Image.open(io.BytesIO(response.content))
        img_path = os.path.join("temp_images", f"{row['property_id']}.png")
        img.save(img_path)
        
        # 3. Add a slide for this property using pptx
        slide = prs.slides.add_slide(blank_slide_layout)
        
        # Add Header Text
        txBox = slide.shapes.add_textbox(Inches(0.8), Inches(0.5), Inches(8), Inches(1))
        tf = txBox.text_frame
        p = tf.paragraphs[0]
        p.text = f"Property Showcase: {row['property_id']}"
        p.font.size = Pt(28)
        p.font.bold = True
        
        # Add Property Details Text
        txBox_details = slide.shapes.add_textbox(Inches(0.8), Inches(1.8), Inches(4), Inches(4))
        tf_details = txBox_details.text_frame
        tf_details.word_wrap = True
        
        p1 = tf_details.paragraphs[0]
        p1.text = f"Address:\n{row['address']}\n"
        p1.font.size = Pt(18)
        
        p2 = tf_details.add_paragraph()
        p2.text = f"Bedrooms: {row['bedrooms']}"
        p2.font.size = Pt(18)
        
        p3 = tf_details.add_paragraph()
        p3.text = f"Price: ${row['price_usd']:,}"
        p3.font.size = Pt(20)
        p3.font.bold = True
        
        # Add Downloaded Image to Slide
        slide.shapes.add_picture(
            img_path, 
            left=Inches(4.8), 
            top=Inches(1.8), 
            width=Inches(4.5)
        )

# ==========================================
# STEP 3: Save final presentation
# ==========================================
output_pptx = "property_showcase_deck.pptx"
prs.save(output_pptx)
print(f"Successfully generated presentation: {output_pptx}")