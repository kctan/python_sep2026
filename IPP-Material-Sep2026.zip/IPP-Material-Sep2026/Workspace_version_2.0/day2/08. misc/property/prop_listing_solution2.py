'''
Write a Python script to automate generating a PowerPoint showcase deck from property data. 

Input (property_listings.xlsx): Columns: property_id, address, bedrooms, price_usd, image_url. 

Output (property_showcase_deck.pptx): Creates one slide per property row containing: A title header displaying "Property Showcase: <property_id>". 

A formatted text block on the left with the address, bedroom count, and price formatted with commas (e.g., $850,000). 

The property image fetched from image_url and placed on the right side of the slide.


'''

import os
from io import BytesIO

import pandas as pd
import requests
from PIL import Image
from pptx import Presentation
from pptx.util import Inches, Pt

# =====================================================
# Configuration
# =====================================================

INPUT_FILE = "property_listings.xlsx"
OUTPUT_FILE = "property_showcase_deck.pptx"
IMAGE_FOLDER = "images"

os.makedirs(IMAGE_FOLDER, exist_ok=True)

# =====================================================
# Read Excel
# =====================================================

df = pd.read_excel(INPUT_FILE)

# =====================================================
# Create PowerPoint
# =====================================================

prs = Presentation()

# Widescreen (16:9)
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)

blank_layout = prs.slide_layouts[6]

# =====================================================
# Process each property
# =====================================================

for _, row in df.iterrows():

    property_id = str(row["property_id"])
    address = str(row["address"])
    bedrooms = row["bedrooms"]
    price = row["price_usd"]
    image_url = str(row["image_url"])

    slide = prs.slides.add_slide(blank_layout)

    # -------------------------------------------------
    # Title
    # -------------------------------------------------

    title_box = slide.shapes.add_textbox(
        Inches(0.4),
        Inches(0.2),
        Inches(12),
        Inches(0.5),
    )

    p = title_box.text_frame.paragraphs[0]
    p.text = f"Property Showcase: {property_id}"
    p.font.size = Pt(28)
    p.font.bold = True

    # -------------------------------------------------
    # Property Information
    # -------------------------------------------------

    info = (
        f"Address:\n"
        f"{address}\n\n"
        f"Bedrooms:\n"
        f"{bedrooms}\n\n"
        f"Price:\n"
        f"${price:,.0f}"
    )

    info_box = slide.shapes.add_textbox(
        Inches(0.5),
        Inches(1.0),
        Inches(4.3),
        Inches(5.5),
    )

    p = info_box.text_frame.paragraphs[0]
    p.text = info
    p.font.size = Pt(22)

    # -------------------------------------------------
    # Download Image
    # -------------------------------------------------

    image_path = os.path.join(IMAGE_FOLDER, f"{property_id}.jpg")

    image_downloaded = False

    try:
        response = requests.get(image_url, timeout=15)
        response.raise_for_status()

        image = Image.open(BytesIO(response.content))
        image.save(image_path)

        image_downloaded = True

    except Exception as e:
        print(f"Unable to download image for {property_id}")
        print(e)

    # -------------------------------------------------
    # Insert Image
    # -------------------------------------------------

    if image_downloaded:

        img = Image.open(image_path)
        width, height = img.size

        max_width = Inches(7)
        max_height = Inches(5.5)

        width_ratio = max_width / width
        height_ratio = max_height / height

        scale = min(width_ratio, height_ratio)

        new_width = width * scale
        new_height = height * scale

        slide.shapes.add_picture(
            image_path,
            Inches(5.4),
            Inches(1.0),
            width=int(new_width),
            height=int(new_height),
        )

    else:

        textbox = slide.shapes.add_textbox(
            Inches(6),
            Inches(3),
            Inches(5),
            Inches(1),
        )

        p = textbox.text_frame.paragraphs[0]
        p.text = "Image not available"
        p.font.size = Pt(24)

# =====================================================
# Save PowerPoint
# =====================================================

prs.save(OUTPUT_FILE)

print(f"PowerPoint saved as '{OUTPUT_FILE}'")