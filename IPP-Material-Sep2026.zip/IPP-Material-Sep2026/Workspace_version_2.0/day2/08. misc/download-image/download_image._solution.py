'''
PROMPT

write the code to download 5 images of cats

'''

import os
import requests

# Create output folder
OUTPUT_FOLDER = "cats"
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# Number of images to download
NUM_IMAGES = 5

# Cat API endpoint
API_URL = f"https://api.thecatapi.com/v1/images/search?limit={NUM_IMAGES}"

# Get image URLs
response = requests.get(API_URL)
response.raise_for_status()

images = response.json()

for i, image in enumerate(images, start=1):
    image_url = image["url"]

    # Determine file extension
    extension = os.path.splitext(image_url)[1]
    if not extension:
        extension = ".jpg"

    filename = os.path.join(OUTPUT_FOLDER, f"cat_{i}{extension}")

    print(f"Downloading {image_url}")

    img_response = requests.get(image_url)
    img_response.raise_for_status()

    with open(filename, "wb") as f:
        f.write(img_response.content)

print(f"\nDownloaded {len(images)} cat images to '{OUTPUT_FOLDER}'")