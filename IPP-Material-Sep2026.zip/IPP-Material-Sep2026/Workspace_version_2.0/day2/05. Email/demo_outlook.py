## REMEMBER to perform a pip install pywin32 first.

import win32com.client
import datetime

outlook = win32com.client.Dispatch('outlook.application')
mail = outlook.CreateItem(0)

# Get today's date formatted as dd-MMM-yyyy
today_str = datetime.date.today().strftime("%d-%b-%Y")

mail.To = 'tan_kok_cheng@rp.edu.sg'
mail.Subject = f"Demo Email {today_str}"
mail.HTMLBody = (
    f"<h3>This is an email sent from Outlook client on {today_str}...</h3>")
#mail.Body = "This is the normal body"
#mail.Attachments.Add('c:\\sample.xlsx')
#mail.Attachments.Add('c:\\sample2.xlsx')
#mail.CC = 'somebody@company.com'
mail.Send()
print("Sent")