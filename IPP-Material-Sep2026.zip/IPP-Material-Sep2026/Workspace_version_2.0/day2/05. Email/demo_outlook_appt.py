import win32com.client
import datetime
import win32com.client

outlook = win32com.client.Dispatch("outlook.application")
appt = outlook.CreateItem(1)

# Dynamically set today's date at 4:00 PM (YYYY-MM-DD 16:00)
today_str = datetime.date.today().strftime("%Y-%m-%d")
appt.Start = f"{today_str} 16:00"

appt.Subject = "Python Lesson!"
appt.Duration = 60
appt.Location = "Singapore"

# mail.Attachments.Add('c:\\sample.xlsx')
# mail.Attachments.Add('c:\\sample2.xlsx')
# mail.CC = 'somebody@company.com'
appt.MeetingStatus = 1  # olMeeting: marks the appointment as a meeting request

appt.Recipients.Add("sitsprint@gmail.com")

appt.Save()
appt.Send()
print("Appt made")